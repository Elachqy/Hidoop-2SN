package ordo;

import java.rmi.*;
import java.util.HashMap;
import java.util.Map;

import formats.*;
import hdfs.*;
import map.*;
import application.*;


public class MapReduceImpl implements MapReduce {

    public static void main(String args[]) {
        Job job = new Job();
        job.setInputFormat(Format.Type.LINE);
        job.setInputFname(args[0]);
        long t1 = System.currentTimeMillis();
        job.startJob(new MapReduceImpl());
        long t2 = System.currentTimeMillis();
        System.out.println("time in ms =" + (t2 - t1));
        System.exit(0);
    }

    @Override
    public void map(FormatReader reader, FormatWriter writer) {

    }

    @Override
    public void reduce(FormatReader reader, FormatWriter writer) {

    }

}
